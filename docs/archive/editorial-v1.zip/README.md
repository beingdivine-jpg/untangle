# Untangle

A working, local prototype for reviewing digital connections after separation. Built for the ImpactHer / SheHacks brief with React, TypeScript and Vite. The entrance uses locally bundled Fraunces and Manrope, warm ivory, plum typography and a continuous thread motif.

## Run locally

Tested with Node 24.12 and npm 11.6. No API keys, paid services, backend or account connection are needed.

```sh
npm ci
npm run dev
```

Open **http://127.0.0.1:5173/**. For a production build, run `npm run build`, then `npm run preview` and open http://127.0.0.1:4173/. Nothing has been deployed.

## Implemented experience

- Responsive editorial entrance, optional concern text and a real local image reference.
- Five-part journey: Start → Review → Connections → Preview → Follow-up.
- Three editable fictional scenarios and a manual mode with supported-topic choice and optional safety context.
- Two separate Google account aliases, session status, device-use context, directed recovery relationship and remaining checks.
- Back navigation, editable answers, skipped/unknown observations, scenario reset, source links and a text-equivalent relationship diagram.
- Conditional previews that never mutate observations or execute account changes.
- Timestamped, user-reported follow-up notes and an adviser summary within the current tab.
- Immediate quick exit, an intentional clear-review confirmation, and in-memory reset on page restoration.

The source brief referenced a design image that was not supplied. The implementation follows its written art direction.

## A 60–90 second demo

1. **0–10 seconds:** Open the homepage and choose **Try an example**. Point out the persistent Fictional example label.
2. **10–30 seconds:** Continue through Main account, the tablet’s listed signed-in session, no longer using the tablet, the recovery email in Backup account, and remaining unreviewed methods. The selected details come from the fictional fixture; they are editable.
3. **30–45 seconds:** Open **Show connections**. Main account is a recovery email **for Backup account**. Explain that this is a possible recovery route, not evidence of access or a guarantee of takeover.
4. **45–60 seconds:** Choose **Preview a change**. The selected-session preview addresses one session; the recovery relationship and other methods remain unresolved. Optionally select the recovery-email preview to see the seven-day caveat.
5. **60–80 seconds:** Continue to Follow-up, select **The selected session now says signed out**, and choose **Record observation**. Point out the timestamp, Reported by you label and remaining recovery check.
6. **80–90 seconds:** Expand **Review together**. End with: “One change can leave other connections open. Untangle makes those remaining checks visible.” This is not a claim of complete safety.

## Fixtures and rule boundaries

| Scenario | Starting observations | Result |
| --- | --- | --- |
| The shared tablet | Selected session signed in; Main account is a recovery email for Backup account; other methods unreviewed | Sign-out preview is limited to that session; recovery relationship remains |
| The password was changed | Reported password change; current session and recovery status unknown | Retains documented exceptions and asks for current settings; no automatic sign-out inference |
| Some details are missing | Session, control and recovery status unknown | Effect not modeled; useful next-check list without confirmed links |

Fixtures live in `src/domain/scenarios.ts`. Pure rules live in `src/domain/rules.ts`, typed observations and predictions in `src/domain/types.ts`, and transitions in `src/app/state.ts`. Questions and source metadata are in `src/content/`. The count is checks reviewed, not a security score. A reviewed unknown remains unresolved. Changing the account alias clears observations tied to the previous account; switching scenarios clears prior scenario state.

## Data handling

Review text, observations, follow-up notes and the image reference exist only in React/browser memory. The app does not use localStorage, sessionStorage, IndexedDB, a service worker, analytics, session replay, account APIs, OCR, an LLM or uploads. User-entered text is rendered as text, never HTML. No personal names, email addresses or credentials are required. Refreshing starts fresh.

Image input accepts one PNG, JPEG or still WebP up to 10 MB, at most 8,000 pixels on either side and 16 million decoded pixels. Header dimensions are checked before image decoding. Failed decoding gives an inline error. Selection and drop use the same handler. Replacing, removing, resetting, exiting and page restoration revoke object URLs; stale asynchronous decoding cannot reintroduce an image after reset. Filenames and image contents are not logged or sent.

The Vite development server uses a local asset/HMR connection. The production app has no background account or third-party connections. Official source links open a separate tab only when selected, without a referrer.

Quick exit synchronously covers content, clears state and calls `location.replace` to Wikipedia. The destination is configured as `EXIT_DESTINATION` in `src/app/App.tsx`; keep the no-JavaScript fallback in `index.html` consistent if changing it. Exit remains available during the inline reset confirmation. `pagehide` clears and covers the app; a persisted `pageshow` resets before uncovering it. No promise is made about erasing history, caches, downloads, monitoring or network records. OS/browser memory disposal is outside this app’s control.

## Verified sources

All five sources below were fetched and reviewed on **3 October 2026**. Runtime metadata is in `src/content/sources.ts`; provider rules are implemented conservatively and include applicability and limitations in the UI.

| Source | Used for |
| --- | --- |
| [Google: See devices with account access](https://support.google.com/accounts/answer/3067630?hl=en) | Session/device distinction, signed-out indicators, selected-session sign-out and activity timestamp limitations |
| [Google: Change or reset your password](https://support.google.com/accounts/answer/41078?hl=en) | Exceptions for verification devices, some third-party app devices and connected home devices |
| [Google: Set up recovery options](https://support.google.com/accounts/answer/183723?hl=en) | Recovery-email direction, account/region/device limits and previous recovery information potentially receiving codes for seven days |
| [NNEDV Safety Net: Quick exit and its limits](https://www.techsafety.org/exit-from-this-website-quickly) | Limits of quick exit and monitored-device context; labeled as US information |
| [W3C: What’s new in WCAG 2.2](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/) | Focus, drag alternatives and target-size considerations; 44 px is this product’s target |

There is no timer that certifies recovery-route removal after seven days. A new observation is still needed, and Untangle cannot independently verify it. Google is not a partner or endorser.

## Validation

```sh
npm run build       # Typecheck and production bundle
npm run lint
npm test            # 15 domain, reducer and image preflight tests
npx playwright install chromium
npm run test:e2e    # 8 browser suites, including screenshots and axe audits
```

Browser coverage includes the complete shared-tablet flow, distinct scenarios, immutable action previews, follow-up, answer preservation, empty submission, manual safety context, image failures and replacement, reset, quick exit, back navigation, and simulated persisted page-lifecycle events. Request interception verifies that review text, filenames and image data are not transmitted; storage checks verify no use of persistent web storage.

Responsive walkthroughs cover 320, 390, 768 and 1440 CSS pixels, plus a 720-pixel reflow equivalent to a 1440-pixel viewport at 200% zoom. This is not a substitute for testing every browser’s native zoom or every assistive technology. Keyboard focus/entry was additionally inspected in the Codex browser. Reduced motion disables animations. Axe checks the homepage, Review, Connections, Preview and Follow-up against WCAG A/AA tags. This does not certify WCAG conformance.

The original muted color failed on lavender (4.18:1). It was adjusted to `#685E6A`, giving 4.79:1 on lavender and 5.63:1 on the canvas. The measured primary button contrast is 5.75:1 and control borders are at least 3.20:1. See [contrast measurements](docs/contrast-report.json) and [automated accessibility results](docs/accessibility-audit.json).

## Screenshots

| View | Desktop | Mobile |
| --- | --- | --- |
| Entrance | [View](docs/screenshots/desktop-home.png) | [View](docs/screenshots/mobile-home.png) |
| Review | [View](docs/screenshots/desktop-review.png) | [View](docs/screenshots/mobile-review.png) |
| Connections | [View](docs/screenshots/desktop-connections.png) | [View](docs/screenshots/mobile-connections.png) |
| Preview | [View](docs/screenshots/desktop-preview.png) | [View](docs/screenshots/mobile-preview.png) |
| Follow-up | [View](docs/screenshots/desktop-followup.png) | [View](docs/screenshots/mobile-followup.png) |

## Remaining limits

- A first prototype, not a production safety tool. User research, practitioner review, competitor differentiation, security review and production readiness are **not completed**.
- No live accounts, automatic changes, proof of ownership/access, OCR, image interpretation, file export, sharing, sign-in, backend or persistent records.
- Scope is two Google account aliases and one selected device/session. Location sharing, finances and other providers are explicitly out of scope.
- Browser automation was run in Chromium; broader Safari/Firefox, screen-reader, operating-system restore, native zoom and real-device coverage remains.
- Persisted page restoration is exercised with browser lifecycle events, alongside actual exit/back navigation. Exhaustive native back/forward-cache behavior across browsers is not established.
- Manual reports and follow-ups can be incomplete or mistaken. Follow-up records do not prove changes succeeded or that all access ended.
- No new user research, prevalence figures, impact claims or competitor findings were invented.

Fonts are installed through Fontsource and bundled locally; their SIL Open Font License files are retained under `public/licenses/`. No runtime third-party font requests are needed.
