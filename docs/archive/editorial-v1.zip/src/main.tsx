import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import '@fontsource-variable/fraunces'
import '@fontsource-variable/fraunces/wght-italic.css'
import '@fontsource-variable/manrope'
import './styles/tokens.css'
import './styles/app.css'
import App from './app/App'

createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>)
