import type { Dispatch } from 'react'
import { ArrowLeft, BookOpen } from 'lucide-react'
import { Button, Choice, SourceLink } from '../../components/Primitives'
import type { Action, State } from '../../app/state'
import type { Account, CheckId } from '../../domain/types'
import { questions } from '../../content/questions'
import { scenarios } from '../../domain/scenarios'
import { PASSWORD_EXCEPTIONS } from '../../domain/rules'

export function Review({ state, dispatch }: { state: State; dispatch: Dispatch<Action> }) {
  const q = questions(state.observations)[state.question]
  const sample = questions(scenarios[state.scenario].observations)[state.question].sample
  const advance = () => state.question === 4 ? dispatch({ type: 'STEP', value: 'connections' }) : dispatch({ type: 'QUESTION', value: state.question + 1 })
  const back = () => state.question > 0 ? dispatch({ type: 'QUESTION', value: state.question - 1 }) : dispatch({ type: 'STEP', value: 'start' })
  return <section className="question-layout"><div className="question-main"><p className="eyebrow">YOUR REVIEW <span className="inline-rule" /> {String(state.question + 1).padStart(2, '0')} OF 05</p><h1 id="step-heading" tabIndex={-1}>{q.title}</h1><p className="step-description">{q.description}</p>
    {state.question === 0 && state.observations.passwordChanged && <aside className="context-note"><BookOpen size={20} aria-hidden="true" /><div><strong>A changed password isn’t the whole picture.</strong><p>{PASSWORD_EXCEPTIONS} Activity timestamps can reflect background syncing; they do not establish who used a session.</p><SourceLink id="password" /></div></aside>}
    <div className="choices" aria-label={q.title}>{q.options.map(option => <Choice key={option.value} selected={state.observations[q.key] === option.value} onClick={() => q.key === 'account' ? dispatch({ type: 'ACCOUNT', value: option.value as Account }) : dispatch({ type: 'ANSWER', key: q.key as CheckId, value: option.value })} description={'description' in option ? option.description : undefined}>{option.label}</Choice>)}</div>
    <SourceLink id={q.source}>Where to look · Google’s guidance</SourceLink><div className="step-actions"><button className="text-button" onClick={back}><ArrowLeft size={16} aria-hidden="true" />Back</button><div>{q.key !== 'account' && <button className="text-button" onClick={() => { dispatch({ type: 'SKIP', key: q.key as CheckId }); advance() }}>Skip for now</button>}<Button arrow onClick={() => { if (q.key !== 'account') dispatch({ type: 'REVIEWED', key: q.key as CheckId }); advance() }}>{state.question === 4 ? 'See my connections' : 'Continue'}</Button></div></div></div>
    <aside className="review-margin">{state.mode === 'example' ? <div className="sample-note"><span className="label-caps">ILLUSTRATIVE EXAMPLE</span><div className="sample-rule" /><BookOpen size={25} strokeWidth={1.3} aria-hidden="true" /><h2>A detail to work with.</h2><p>{state.observations.account === 'Main account' ? sample : 'No example is supplied for this account label. You can leave the details unknown.'}</p><span className="sample-caption">Locally created sample. Not connected to Google.</span></div> : <div className="sample-note"><span className="label-caps">AT YOUR OWN PACE</span><h2>“Not sure” is a useful answer.</h2><p>You don’t have to open your settings now. An unfinished check can simply stay on your list.</p></div>}<p className="margin-note">A listed session does not tell us who used it. A recovery email is a possible route, not proof of access.</p></aside>
  </section>
}
