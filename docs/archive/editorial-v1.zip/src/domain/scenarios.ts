import type { Observations, ScenarioId } from './types'

export const emptyObservations = (): Observations => ({ account: 'Main account', session: 'unknown', control: 'unknown', recovery: 'unknown', remaining: 'unknown', passwordChanged: false, reviewed: [] })
export const scenarios: Record<ScenarioId, { title: string; description: string; observations: Observations }> = {
  tablet: {
    title: 'The shared tablet',
    description: 'You used to share a tablet. A session is still listed, and a second account has a recovery connection.',
    observations: { ...emptyObservations(), session: 'signed-in', control: 'no', recovery: 'present', remaining: 'yes' },
  },
  password: {
    title: 'The password was changed',
    description: 'You changed a password and expected every device to disconnect. Let’s look at what the current settings actually show.',
    observations: { ...emptyObservations(), passwordChanged: true, control: 'no', remaining: 'yes' },
  },
  incomplete: {
    title: 'Some details are missing',
    description: 'The session and recovery details are unclear. You can still find a useful next step without guessing.',
    observations: emptyObservations(),
  },
}
