import type { Mode, Observations, Prediction, PreviewAction, Relationship } from './types'

export const otherAccount = (account: Observations['account']) => account === 'Main account' ? 'Backup account' : 'Main account'
export const sessionLabels = { 'signed-in': 'Listed as signed in', 'signed-out': 'Listed as signed out', 'not-shown': 'Not shown', unknown: 'Not sure' }
export const recoverySentence = (o: Observations) => `${o.account} is a recovery email for ${otherAccount(o.account)}.`
export const PASSWORD_EXCEPTIONS = 'A password change has exceptions: verification devices, some devices with third-party app access, and connected home devices may remain signed in.'

export function relationships(o: Observations, mode: Mode): Relationship[] {
  const category = mode === 'example' ? 'Example data' : 'User reported'
  const result: Relationship[] = []
  if (o.session === 'signed-in') result.push({ id: 'tablet-session', from: 'Shared tablet', to: o.account, label: 'Listed as signed in', category })
  if (o.recovery === 'present') result.push({ id: 'recovery-email', from: o.account, to: otherAccount(o.account), label: 'Recovery email for', category })
  return result
}

export function nextChecks(o: Observations): string[] {
  const checks: string[] = []
  if (o.session === 'unknown' || o.session === 'not-shown') checks.push(`Confirm the selected session’s current status in ${o.account}. A missing listing alone does not establish that all access ended.`)
  if (o.session === 'signed-in') checks.push(`Review the selected Shared tablet session in ${o.account}.`)
  if (o.control === 'unknown') checks.push('Consider whether you still use or control Shared tablet; this is your context, not ownership verification.')
  if (o.recovery === 'unknown') checks.push(`Check whether ${otherAccount(o.account)} uses ${o.account} as its recovery email.`)
  if (o.recovery === 'present') checks.push(`Review the recovery email configured in ${otherAccount(o.account)}.`)
  if (o.remaining !== 'no') checks.push('Review other sessions and alternate recovery methods, including the recovery phone.')
  if (o.passwordChanged) checks.push('Check current sessions after the password change, including documented exceptions.')
  return checks
}

export function preview(o: Observations, action: PreviewAction): Prediction {
  const common = {
    prerequisites: ['Consider whether a settings change could be noticed or create a problem for you.', 'Read the provider guidance and keep a recovery method you can use. Any actual change is your separate choice outside Untangle.'],
    applicability: 'Google account settings only; available options can vary by account, region and device. Work or school accounts may need administrator guidance.',
    limitations: 'This is a conditional preview. Untangle cannot check account access, identify who used a session, or change settings.',
  }
  if (action === 'sign-out') {
    const modeled = o.session === 'signed-in'
    return { ...common, confidence: modeled ? 'Expected effect' : 'Effect not modeled', explanation: 'Only the selected, reported session is in this preview.', affectedRelationshipIds: modeled ? ['tablet-session'] : [], expectedEffect: modeled ? `If sign-out succeeds in Google, the selected Shared tablet session for ${o.account} should be shown as signed out. Confirm what the settings show afterward.` : 'There is no reported signed-in session to model. Check the current listing before drawing a conclusion.', unresolved: [...(o.recovery === 'present' ? [recoverySentence(o) + ' Signing out this session does not change that setting.'] : o.recovery === 'unknown' ? ['The recovery-email relationship is still unknown.'] : []), 'Other sessions, alternate recovery methods and any copies of data remain outside this preview.', ...(o.passwordChanged ? [PASSWORD_EXCEPTIONS] : [])], sourceIds: o.passwordChanged ? ['devices', 'password'] : ['devices'] }
  }
  const modeled = o.recovery === 'present'
  return { ...common, confidence: modeled ? 'Expected effect' : 'Effect not modeled', explanation: `This preview concerns the recovery setting in ${otherAccount(o.account)}.`, affectedRelationshipIds: modeled ? ['recovery-email'] : [], expectedEffect: modeled ? `Changing the recovery email in ${otherAccount(o.account)} can update its configured recovery information. Google may still send codes to previous information for seven days; this route is not modeled as immediately removed.` : 'The recovery relationship has not been reported present, so its removal cannot be modeled. First check the recovery setting.', unresolved: ['Previous recovery information may still receive codes for seven days after a change. Elapsed time alone does not confirm that the route has ended.', 'A new observation is needed. Untangle cannot independently verify removal.', 'The selected session, other sessions and alternate recovery methods are not changed by this preview.'], sourceIds: ['recovery'] }
}
