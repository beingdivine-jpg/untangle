import { useCallback, useEffect, useReducer, useState } from 'react'
import { flushSync } from 'react-dom'
import { ArrowUpRight, Check, MoveUpRight, X } from 'lucide-react'
import { reducer, initialState } from './state'
import { Thread } from '../components/Thread'
import { Button, Privacy, SourceLink } from '../components/Primitives'
import { Landing } from '../features/start/Landing'
import { Start } from '../features/start/Start'
import { Review } from '../features/review/Review'
import { Connections } from '../features/connections/Connections'
import { Preview } from '../features/preview/Preview'
import { Followup } from '../features/followup/Followup'
import { useLocalImage } from '../features/start/useLocalImage'
import { ImageReference } from '../features/start/ImageReference'
import { scenarios } from '../domain/scenarios'
import type { ScenarioId, Step } from '../domain/types'

const journey: { id: Step; label: string }[] = [{ id: 'start', label: 'Start' }, { id: 'review', label: 'Review' }, { id: 'connections', label: 'Connections' }, { id: 'preview', label: 'Preview' }, { id: 'followup', label: 'Follow-up' }]
const EXIT_DESTINATION = 'https://www.wikipedia.org/'

export default function App() {
  const [state, dispatch] = useReducer(reducer, undefined, initialState)
  const image = useLocalImage()
  const [confirmReset, setConfirmReset] = useState(false)
  const [info, setInfo] = useState<'how' | 'about' | null>(null)
  const clearImage = image.clear
  const reset = useCallback(() => { clearImage(); dispatch({ type: 'RESET' }); setConfirmReset(false); setInfo(null) }, [clearImage])
  const resetAndFocus = () => { flushSync(reset); window.scrollTo({ top: 0, behavior: 'instant' }); document.querySelector<HTMLElement>('#hero-title')?.focus() }
  const exit = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault()
    document.documentElement.dataset.exiting = 'true'
    flushSync(reset)
    window.location.replace(EXIT_DESTINATION)
  }
  useEffect(() => {
    const hide = () => { document.documentElement.dataset.exiting = 'true'; flushSync(reset) }
    const restore = (e: PageTransitionEvent) => { if (e.persisted) { flushSync(reset); delete document.documentElement.dataset.exiting } }
    window.addEventListener('pagehide', hide)
    window.addEventListener('pageshow', restore)
    return () => { window.removeEventListener('pagehide', hide); window.removeEventListener('pageshow', restore) }
  }, [reset])
  useEffect(() => {
    if (state.active) {
      document.getElementById('step-heading')?.focus({ preventScroll: true })
      window.scrollTo({ top: 0, behavior: 'instant' })
    }
  }, [state.active, state.step, state.question, state.startPhase, state.scenario])
  const startExample = (scenario: ScenarioId = 'tablet') => { image.clear(); setConfirmReset(false); setInfo(null); dispatch({ type: 'EXAMPLE', scenario }) }
  const index = journey.findIndex(item => item.id === state.step)
  return <>
    <a className="skip-link" href="#main-content">Skip to content</a>
    <header className="site-header"><button className="wordmark" aria-label="Untangle home" onClick={() => state.active ? setConfirmReset(true) : window.scrollTo({ top: 0, behavior: 'smooth' })}><Thread small /><span>untangle<span className="wordmark-period">.</span></span></button><nav aria-label="Main navigation">{state.active ? <><button className="nav-link" onClick={() => setInfo(info === 'how' ? null : 'how')}>How it works</button><button className="nav-link" onClick={() => setInfo(info === 'about' ? null : 'about')}>About this prototype</button></> : <><a className="nav-link" href="#how-it-works">How it works</a><a className="nav-link" href="#about">About this prototype</a></>}<a className="exit-link" href={EXIT_DESTINATION} onClick={exit} rel="noreferrer">Leave this page<MoveUpRight size={16} aria-hidden="true" /></a></nav></header>
    {info && <section className="info-panel"><button className="icon-button" aria-label="Close information" onClick={() => setInfo(null)}><X size={20} aria-hidden="true" /></button><h2>{info === 'how' ? 'One clear step at a time.' : 'About this prototype'}</h2><p>{info === 'how' ? 'Choose a starting point, review what you know, see the connections, preview a change, then keep unfinished checks visible. You can return to earlier answers at any time.' : 'Untangle is an ImpactHer / SheHacks prototype for women reviewing digital connections after separation. Google is a proposed starting point, not a partner. We use manual observations and fictional examples, without account access. Research, practitioner review and security review remain to be done.'}</p><Privacy />{info === 'about' && <div className="info-sources">{(['devices', 'password', 'recovery', 'safety'] as const).map(id => <SourceLink id={id} key={id} />)}</div>}</section>}
    {confirmReset && <section className="reset-confirm" role="alert"><div><strong>Clear this review and start fresh?</strong><p>Your answers, image and follow-up notes will be removed from this tab.</p></div><div><Button secondary onClick={() => setConfirmReset(false)}>Keep reviewing</Button><Button onClick={resetAndFocus}>Yes, clear review</Button></div></section>}
    {!state.active ? <Landing state={state} dispatch={dispatch} image={image} startExample={() => startExample()} /> : <main id="main-content" className="review-shell">
      <div className="review-toolbar"><div className="mode-label"><span className={`status-tag ${state.mode === 'example' ? 'lavender' : 'sage'}`}><span aria-hidden="true">◌</span>{state.mode === 'example' ? 'Fictional example' : 'Your personal review'}</span>{state.mode === 'example' ? <label className="scenario-picker"><span className="sr-only">Choose fictional scenario</span><select value={state.scenario} onChange={e => startExample(e.target.value as ScenarioId)}>{Object.entries(scenarios).map(([id, scenario]) => <option key={id} value={id}>{scenario.title}</option>)}</select></label> : <span className="toolbar-note">Your observations. No account connection.</span>}</div><button className="text-button clear-button" onClick={() => setConfirmReset(true)}>Clear this review<X size={14} aria-hidden="true" /></button></div>
      <nav className="journey" aria-label="Review progress"><p className="journey-caption">Step {index + 1} of 5 <span aria-hidden="true">·</span> {journey[index].label}</p><ol>{journey.map((item, i) => <li key={item.id} className={`${i === index ? 'current' : ''} ${i < index ? 'past' : ''}`}><button disabled={i > index} aria-current={i === index ? 'step' : undefined} onClick={() => dispatch({ type: 'STEP', value: item.id })}><span className="step-number">{i < index ? <Check size={12} aria-hidden="true" /> : i + 1}</span><span>{item.label}</span></button></li>)}</ol></nav>
      {(state.safety === 'possibly' || state.safety === 'unsure') && <aside className="safety-context"><span>Space to understand, without making a change.</span><SourceLink id="safety">Support information (US)</SourceLink></aside>}
      {image.url && <details className="review-image"><summary>Image reference — confirm the details below</summary><ImageReference image={image} compact /></details>}
      <div className="step-content" key={`${state.step}-${state.question}-${state.startPhase}-${state.scenario}`}>{state.step === 'start' && <Start state={state} dispatch={dispatch} />}{state.step === 'review' && <Review state={state} dispatch={dispatch} />}{state.step === 'connections' && <Connections state={state} dispatch={dispatch} />}{state.step === 'preview' && <Preview state={state} dispatch={dispatch} />}{state.step === 'followup' && <Followup state={state} dispatch={dispatch} />}</div>
      <div className="review-bottom"><span className="small-print">Your pace. Your choices.</span><Privacy /></div>
    </main>}
    <footer className="site-footer"><div><Thread small /><span>A little clarity. A little more you.</span></div><span>A thoughtful first prototype <span aria-hidden="true">↗</span></span></footer>
    <div className="sr-only" role="status" aria-live="polite">{state.active ? `${journey[index].label}, step ${index + 1} of 5${state.step === 'review' ? `, question ${state.question + 1} of 5` : ''}` : 'Welcome to Untangle.'}</div>
    <div className="exit-cover" aria-hidden="true"><ArrowUpRight size={20} /></div>
  </>
}
