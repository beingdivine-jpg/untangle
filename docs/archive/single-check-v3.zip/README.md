# Untangle

A working, local prototype for reviewing digital connections after separation. Built for ImpactHer at HackYeah with React, TypeScript and Vite. The interface uses familiar navigation, plain explanations and one question at a time. It helps a first-time visitor understand the purpose, practise with a made-up story, and find a small next step.

The previous guided interface is preserved in [guided-v2.zip](docs/archive/guided-v2.zip). The earlier editorial version is preserved in [editorial-v1.zip](docs/archive/editorial-v1.zip), including source, configuration, lockfile, README and screenshots. Extract it into a separate directory and run `npm ci` to restore that version. The redesigned app remains in the main project.

## Run locally

Tested with Node 24.12 and npm 11.6. No API keys, paid services, backend or account connection are needed.

```sh
npm ci
npm run dev
```

Open **http://127.0.0.1:5173/**. For a production build, run `npm run build`, then `npm run preview` and open http://127.0.0.1:4173/. Nothing has been deployed.

## Beginner route

The first visit now has one primary action: **Help me take the first step**. It helps a person look at one entry in Google's device list, instead of asking them to understand account relationships first.

1. Explain the small task before opening settings; offer a made-up example or a way to stop.
2. Open Google's device list in a separate tab using the shortcut in Google's official guidance. The app cannot read the other tab. Never enter credentials in Untangle.
3. Look for a phone, tablet or computer the person used together with their ex. No assumed tablet or second account.
4. Look for “Signed out” on one entry. A missing label is described as *possibly* signed in, not proof that another person has access.
5. Explain that one reported detail, offer one next step, and let the person finish. Other devices and recovery methods remain unchecked.

“I don’t know if I use Google”, “I’m stuck”, missing devices and unreadable details have separate paths. Unknown answers are not guessed or converted into completed checks. Practice shows and explains a made-up story without quizzing the person. Its outcome stays clearly fictional and never connects to Google. Help, back navigation, refresh/reset and quick exit use the same in-memory boundaries as the detailed review.

### Why the flow changed

A cognitive walkthrough used the perspective of a first-time visitor after a breakup. It is an interface review, not research with an actual young person.

| Barrier in the earlier flow | Change |
| --- | --- |
| “I’m not sure” led to the same technical questionnaire | A short route that helps find the answer first |
| Main/Backup account nicknames required explanation | No aliases in the beginner route |
| A shared tablet was assumed | Look for a familiar phone, tablet or computer |
| Definitions and five-stage navigation made mobile pages long | One task per screen; three concrete instructions |
| Several unknown answers produced a long list of unfinished work | One explanation and one next step, with a stopping point |

## Detailed review retained

Open **Open the detailed review** below the first-step card to access the original features:

- Responsive app layout with Start here, How it works and Help & words navigation.
- Clear starting choices for a shared device, linked email accounts or “I’m not sure where to start”.
- A prominent made-up example, plain definitions alongside each question, and expandable “Show me where to look” instructions.
- Help explains the purpose, unfamiliar words, unknown answers and what buttons do; returning from help preserves the question, answers and open instructions.
- Five-part journey: Start → Your answers → Your summary → Your options → Next steps. Visited stages remain available when going back.
- Optional concern text and a real local image reference, behind an expandable control.
- Three editable fictional scenarios and a manual mode with supported-topic choice and optional safety context.
- Two separate Google account aliases, session status, device-use context, directed recovery relationship and remaining checks.
- Back navigation, editable answers, skipped/unknown observations, scenario reset, source links and a text-equivalent relationship diagram.
- Conditional previews that never mutate observations or execute account changes.
- Timestamped, user-reported follow-up notes and an adviser summary within the current tab.
- Immediate quick exit, an intentional clear-review confirmation, and in-memory reset on page restoration.

The redesign preserves the review, relationship diagram, conditional previews, follow-up, sources and privacy boundaries. Notes, diagrams and detailed source information use expandable controls to reduce the initial reading load. Manrope is used for interface text, with Fraunces retained in the wordmark; fonts are bundled locally.

## A short beginner demo

Choose **Try without using my account** → **Show me the example** → **I can see the example list** → **Look at the shared laptop** → **Explain this example**. Explain the conditional result, open **What would signing out do?**, then choose **That’s enough for now**. The goal is understanding one detail, not a claim that the person's accounts are safe.

## A 60–90 second detailed demo

1. **0–10 seconds:** Open **Open the detailed review** on the homepage and choose **Show me an example**. Point out the persistent Fictional example label.
2. **10–30 seconds:** Continue through Main account, the tablet’s listed signed-in session, no longer using the tablet, the recovery email in Backup account, and remaining unreviewed methods. The selected details come from the fictional fixture; they are editable.
3. **30–45 seconds:** Open **Show connections**. Main account is a recovery email **for Backup account**. Explain that this is a possible recovery route, not evidence of access or a guarantee of takeover.
4. **45–60 seconds:** Choose **See my options**. The selected-session preview addresses one session; the recovery relationship and other methods remain unresolved. Optionally select the recovery-email preview to see the seven-day caveat.
5. **60–80 seconds:** Choose **Make my next-step list**, select **The selected session now says signed out**, and choose **Add this update**. Point out the timestamp, Reported by you label and remaining recovery check.
6. **80–90 seconds:** Expand **Review together**. End with: “One change can leave other connections open. Untangle makes those remaining checks visible.” This is not a claim of complete safety.

## Fixtures and rule boundaries

| Scenario | Starting observations | Result |
| --- | --- | --- |
| The shared tablet | Selected session signed in; Main account is a recovery email for Backup account; other methods unreviewed | Sign-out preview is limited to that session; recovery relationship remains |
| The password was changed | Reported password change; current session and recovery status unknown | Retains documented exceptions and asks for current settings; no automatic sign-out inference |
| Some details are missing | Session, control and recovery status unknown | Effect not modeled; useful next-check list without confirmed links |

Fixtures live in `src/domain/scenarios.ts`. Pure rules live in `src/domain/rules.ts`, typed observations and predictions in `src/domain/types.ts`, and transitions in `src/app/state.ts`. Questions and source metadata are in `src/content/`. The count is checks reviewed, not a security score. A reviewed unknown remains unresolved. Changing the account alias clears observations tied to the previous account; switching scenarios clears prior scenario state.

## Data handling

Review text, observations, follow-up notes and the image reference exist only in React/browser memory. The app does not use localStorage, sessionStorage, IndexedDB, a service worker, analytics, session replay, account APIs, OCR, an LLM or uploads. User-entered text is rendered as text, never HTML. No personal names, email addresses or credentials are required. Refreshing starts fresh.

Image input accepts one PNG, JPEG or still WebP up to 10 MB, at most 8,000 pixels on either side and 16 million decoded pixels. Header dimensions are checked before image decoding. Failed decoding gives an inline error. Selection and drop use the same handler. Replacing, removing, resetting, exiting and page restoration revoke object URLs; stale asynchronous decoding cannot reintroduce an image after reset. Filenames and image contents are not logged or sent.

The Vite development server uses a local asset/HMR connection. The production app has no background account or third-party connections. Official source links open a separate tab only when selected, without a referrer.

Quick exit synchronously covers content, clears state and calls `location.replace` to Wikipedia. The destination is configured as `EXIT_DESTINATION` in `src/app/App.tsx`; keep the no-JavaScript fallback in `index.html` consistent if changing it. Exit remains available during the inline reset confirmation. `pagehide` clears and covers the app; a persisted `pageshow` resets before uncovering it. No promise is made about erasing history, caches, downloads, monitoring or network records. OS/browser memory disposal is outside this app’s control.

## Verified sources

All five sources below were fetched and reviewed on **3 October 2026**. Runtime metadata is in `src/content/sources.ts`; provider rules are implemented conservatively and include applicability and limitations in the UI.

| Source | Used for |
| --- | --- |
| [Google: See devices with account access](https://support.google.com/accounts/answer/3067630?hl=en) | Session/device distinction, signed-out indicators, selected-session sign-out and activity timestamp limitations |
| [Google: Change or reset your password](https://support.google.com/accounts/answer/41078?hl=en) | Exceptions for verification devices, some third-party app devices and connected home devices |
| [Google: Set up recovery options](https://support.google.com/accounts/answer/183723?hl=en) | Recovery-email direction, account/region/device limits and previous recovery information potentially receiving codes for seven days |
| [NNEDV Safety Net: Quick exit and its limits](https://www.techsafety.org/exit-from-this-website-quickly) | Limits of quick exit and monitored-device context; labeled as US information |
| [W3C: What’s new in WCAG 2.2](https://www.w3.org/WAI/standards-guidelines/wcag/new-in-22/) | Focus, drag alternatives and target-size considerations; 44 px is this product’s target |

There is no timer that certifies recovery-route removal after seven days. A new observation is still needed, and Untangle cannot independently verify it. Google is not a partner or endorser.

## Validation

```sh
npm run build       # Typecheck and production bundle
npm run lint
npm test            # 18 domain, reducer and image preflight tests
npx playwright install chromium
npm run test:e2e    # 14 browser suites, including screenshots and axe audits
```

Browser coverage includes the short guide, a stubbed external Google tab, practice/unknown/paused outcomes, mobile first-action visibility, help with preserved answers, returning directly to previously visited stages, the complete shared-tablet flow, distinct scenarios, immutable action previews, follow-up, answer preservation, empty submission, manual safety context, image failures and replacement, reset, quick exit, back navigation, and simulated persisted page-lifecycle events. Request interception verifies that review text, filenames and image data are not transmitted; storage checks verify no use of persistent web storage.

Responsive walkthroughs cover 320, 390, 768 and 1440 CSS pixels, plus a 720-pixel reflow equivalent to a 1440-pixel viewport at 200% zoom. This is not a substitute for testing every browser’s native zoom or every assistive technology. Keyboard focus/entry was additionally inspected in the Codex browser. Reduced motion disables animations. Axe checks the homepage, questions, summary, options, next steps and help against WCAG A/AA tags. This does not certify WCAG conformance.

The muted text color `#685E6A` gives 5.26:1 on the new lavender card, 5.56:1 on the peach wash and 5.63:1 on the canvas. The measured primary button contrast is 5.75:1 and control borders are at least 3.20:1. See [contrast measurements](docs/contrast-report.json) and [detailed-review accessibility results](docs/accessibility-audit.json) and [short-guide accessibility results](docs/guide-accessibility-audit.json).

## Screenshots

| View | Desktop | Mobile |
| --- | --- | --- |
| Entrance | [View](docs/screenshots/home.png) | [View](docs/screenshots/home-mobile.png) |
| Short guide | [View](docs/screenshots/guide.png) | [View](docs/screenshots/guide-mobile.png) |
| Short-guide result | [View](docs/screenshots/guide-result.png) | [View](docs/screenshots/guide-result-mobile.png) |
| Your answers | [View](docs/screenshots/desktop-review.png) | [View](docs/screenshots/mobile-review.png) |
| Your summary | [View](docs/screenshots/desktop-connections.png) | [View](docs/screenshots/mobile-connections.png) |
| Your options | [View](docs/screenshots/desktop-preview.png) | [View](docs/screenshots/mobile-preview.png) |
| Next steps | [View](docs/screenshots/desktop-followup.png) | [View](docs/screenshots/mobile-followup.png) |
| Help & words | [View](docs/screenshots/desktop-help.png) | [View](docs/screenshots/mobile-help.png) |

## Remaining limits

- First-time and teenage usability has not yet been tested with real users. Plain-language design and automated checks do not establish that everyone will understand the flow.
- A first prototype, not a production safety tool. User research, practitioner review, competitor differentiation, security review and production readiness are **not completed**.
- No live accounts, automatic changes, proof of ownership/access, OCR, image interpretation, file export, sharing, sign-in, backend or persistent records.
- The short guide covers one Google device entry. The detailed review covers two Google account aliases and one selected device/session. Location sharing, finances and other providers are explicitly out of scope.
- Browser automation was run in Chromium; broader Safari/Firefox, screen-reader, operating-system restore, native zoom and real-device coverage remains.
- Persisted page restoration is exercised with browser lifecycle events, alongside actual exit/back navigation. Exhaustive native back/forward-cache behavior across browsers is not established.
- Manual reports and follow-ups can be incomplete or mistaken. Follow-up records do not prove changes succeeded or that all access ended.
- No new user research, prevalence figures, impact claims or competitor findings were invented.

Fonts are installed through Fontsource and bundled locally; their SIL Open Font License files are retained under `public/licenses/`. No runtime third-party font requests are needed.
