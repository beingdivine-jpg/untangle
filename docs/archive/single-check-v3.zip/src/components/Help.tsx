import { ChevronDown, CircleHelp, Mail, Monitor, UserRound } from 'lucide-react'
import { Privacy, SourceLink } from './Primitives'

export function Help() {
  return <div className="help-content">
    <div className="help-intro"><span className="icon-tile lavender"><CircleHelp size={23} aria-hidden="true" /></span><div><h3>It’s okay to be new to this.</h3><p>The short guide helps you look at one device in your Google account. It explains what you tell us you saw. It cannot see your accounts, tell who used them, or change settings.</p></div></div>
    <div className="glossary"><article><UserRound size={20} aria-hidden="true" /><h3>Account</h3><p>Your sign-in for a service, such as Gmail. The same account can be open on more than one device.</p></article><article><Monitor size={20} aria-hidden="true" /><h3>Signed in / session</h3><p>An account is open in an app or browser. Google calls each sign-in a session. One device can have several.</p></article><article><Mail size={20} aria-hidden="true" /><h3>Recovery email</h3><p>An email Google may use to help you get back into another account. It does not automatically give someone access.</p></article></div>
    <details className="help-answer"><summary>Do I need to open my Google settings now?<ChevronDown size={17} aria-hidden="true" /></summary><p>No. You can try the made-up example or choose “I’m not sure”. On each question, “Show me where to look” explains where the setting is. You decide whether to open it.</p></details>
    <details className="help-answer"><summary>What if I don’t know an answer?<ChevronDown size={17} aria-hidden="true" /></summary><p>In the short guide, use “I’m stuck” or “I’m not sure”. We’ll help you pause or practise with made-up details. The detailed review also lets you skip questions.</p></details>
    <details className="help-answer"><summary>Will clicking a button change my account?<ChevronDown size={17} aria-hidden="true" /></summary><p>No. Buttons here only move through the guide or record your answers in this tab. The options screen explains what a change might do. Any real change would happen separately in Google.</p></details>
    <details className="help-answer"><summary>I’d rather go through this with someone.<ChevronDown size={17} aria-hidden="true" /></summary><p>You can ask a trusted person or adviser to sit with you. At the end of the short guide, “Read this with someone I trust” opens a short summary. The detailed review has a “Review together” summary. It does not send or share anything.</p><SourceLink id="safety">General safety information from NNEDV (US)</SourceLink></details>
    <Privacy />
  </div>
}
